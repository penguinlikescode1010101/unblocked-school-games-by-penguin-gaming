Cloudflare version of the proxy
================================

Easiest way (no installs): Cloudflare Pages, Direct Upload
  1. Sign in at dash.cloudflare.com and open Workers & Pages.
  2. Create a new Pages project and choose "Upload assets" (Direct Upload).
  3. Drag in the "site" folder from this download (it holds index.html and _worker.js).
  4. Deploy. Cloudflare gives you a https://something.pages.dev address.
  5. Recommended: open the project's Settings > Variables and Secrets and add
     ACCESS_PASSWORD with a password you choose, then deploy again.

Command line way (needs Node.js):
  1. In this folder run:  npx wrangler login
  2. Run:                 npx wrangler deploy
  3. Set a password:      npx wrangler secret put ACCESS_PASSWORD

Notes
  - Cloudflare's menus change sometimes, so look for "Pages" and "Upload assets" if names differ.
  - The free plan allows about 100,000 requests a day.
  - Some websites block Cloudflare's servers, so a few may not load.
  - Without ACCESS_PASSWORD anyone with your link can use the proxy.
  - Open the site, scroll to the bottom of School Tips & Info, and use the faint "code" button (2323).
