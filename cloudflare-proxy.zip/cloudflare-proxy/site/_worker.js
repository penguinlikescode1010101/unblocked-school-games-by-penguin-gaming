// Cloudflare Worker: serves the site (index.html) and acts as the web proxy.
// Works as a Pages "_worker.js" (advanced mode) and as a Workers script with static assets.
//
// Settings (Cloudflare dashboard > your project > Settings > Variables and Secrets):
//   ACCESS_PASSWORD  optional. If set, visitors must enter it (any username).

const text = (msg, status) => new Response(msg, { status, headers: { 'content-type': 'text/plain; charset=utf-8' } });

// Refuse obviously private or internal targets.
function isPrivateHost(h) {
  h = h.replace(/^\[|\]$/g, '').toLowerCase();
  if (/^(localhost|.*\.localhost|.*\.local|.*\.internal|.*\.lan)$/.test(h)) return true;
  if (/^\d+\.\d+\.\d+\.\d+$/.test(h)) {
    const [a, b] = h.split('.').map(Number);
    return a === 10 || a === 127 || a === 0 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
  }
  if (h.includes(':')) return h === '::1' || h === '::' || h.startsWith('fc') || h.startsWith('fd') || h.startsWith('fe80') || h.startsWith('::ffff:');
  return false;
}

async function sha(s) { return new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s))); }
async function authorized(request, env) {
  const pw = env.ACCESS_PASSWORD;
  if (!pw) return true;
  const h = request.headers.get('Authorization') || '';
  if (!h.startsWith('Basic ')) return false;
  let given;
  try { given = new TextDecoder().decode(Uint8Array.from(atob(h.slice(6)), c => c.charCodeAt(0))); } catch (_) { return false; }
  given = given.split(':').slice(1).join(':');
  const [a, b] = await Promise.all([sha(given), sha(pw)]);
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

// Point links, images, scripts and forms back through the proxy; drop <base> and integrity checks.
function rewriter(base) {
  const skip = /^(#|javascript:|data:|mailto:|tel:|blob:)/i;
  const attr = name => ({
    element(el) {
      const v = el.getAttribute(name);
      if (!v || skip.test(v.trim())) return;
      try { el.setAttribute(name, '/proxy?url=' + encodeURIComponent(new URL(v.trim(), base).href)); } catch (_) {}
    },
  });
  return new HTMLRewriter()
    .on('[href]', attr('href'))
    .on('[src]', attr('src'))
    .on('[action]', attr('action'))
    .on('base', { element(el) { el.remove(); } })
    .on('[integrity]', { element(el) { el.removeAttribute('integrity'); } });
}

async function proxy(request, url, env) {
  let t;
  try { t = new URL(url.searchParams.get('url')); } catch (_) { return text('Proxy error: invalid URL', 400); }
  if (!/^https?:$/.test(t.protocol)) return text('Proxy error: only http and https are allowed', 400);
  if (env.ALLOW_PRIVATE !== '1' && (isPrivateHost(t.hostname) || t.hostname === url.hostname)) return text('Proxy error: blocked address', 403);

  const headers = new Headers();
  ['user-agent', 'accept', 'accept-language'].forEach(n => { const v = request.headers.get(n); if (v) headers.set(n, v); });
  if (!headers.has('user-agent')) headers.set('user-agent', 'Mozilla/5.0');
  const init = { method: request.method, headers, redirect: 'manual' };
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    init.body = await request.arrayBuffer();
    const ct = request.headers.get('content-type');
    if (ct) headers.set('content-type', ct);
  }

  let up;
  try { up = await fetch(t.href, init); } catch (e) { return text('Proxy error: ' + e.message, 502); }

  const loc = up.headers.get('location');
  if (up.status >= 300 && up.status < 400 && loc) {
    const next = new URL(loc, t.href).href;
    return new Response(null, { status: up.status === 307 || up.status === 308 ? up.status : 302, headers: { Location: '/proxy?url=' + encodeURIComponent(next) } });
  }

  const ct = up.headers.get('content-type') || 'application/octet-stream';
  const out = new Headers({ 'content-type': ct, 'cache-control': 'no-store' });
  const res = new Response(up.body, { status: up.status, headers: out });
  return /text\/html/i.test(ct) ? rewriter(t.href).transform(res) : res;
}

// Downloads an extension from the Chrome Web Store for the Extensions manager.
async function crx(url) {
  const id = url.searchParams.get('id') || '';
  if (!/^[a-p]{32}$/.test(id)) return text('Bad extension id', 400);
  try {
    const r = await fetch('https://clients2.google.com/service/update2/crx?response=redirect&prodversion=130.0.0.0&acceptformat=crx2,crx3&x=' +
      encodeURIComponent('id=' + id + '&installsource=ondemand&uc'));
    if (!r.ok) throw new Error('Chrome Web Store answered ' + r.status);
    const buf = await r.arrayBuffer();
    if (buf.byteLength > 60e6) throw new Error('extension is too large');
    return new Response(buf, { headers: { 'content-type': 'application/octet-stream', 'cache-control': 'no-store' } });
  } catch (e) {
    return text('Download failed: ' + e.message, 502);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!(await authorized(request, env))) {
      return new Response('Password required', { status: 401, headers: { 'WWW-Authenticate': 'Basic realm="Proxy"', 'content-type': 'text/plain' } });
    }
    if (url.pathname === '/health') return new Response('ok', { headers: { 'cache-control': 'no-store' } });
    // Workers can't keep one shared counter, so the page measures its own traffic instead.
    if (url.pathname === '/stats') return Response.json({ bytes: null, requests: null }, { headers: { 'cache-control': 'no-store' } });
    if (url.pathname === '/crx') return crx(url);
    if (url.pathname === '/proxy') return proxy(request, url, env);
    return env.ASSETS.fetch(request);
  },
};
